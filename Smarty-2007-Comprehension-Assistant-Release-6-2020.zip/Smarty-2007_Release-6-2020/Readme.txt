﻿* "Smarty" - English-Bulgarian Comprehension Assistant (Intelligent Dictionary)

(C) Todor Arnaudov - Tosh, 2007
    Supervisor: Ruslan Mitkov

    See below and future specifications

 http://twenkid.com
 http://artificial-mind.blogspot.com
 https://github.com/Twenkid/Smarty/

This release: 15.6.2020

Version 0.09 NB, 2007

Some more info: http://artificial-mind.blogspot.com/2008/07/smarty-extendable-framework-for.html

Project code base complexity according to the link: ~ 9000 lines in C#

*** Manual and Technical Info ***

See /README folder
See the thesis, the slides and the paper for LREC 2008 and IMSCIT 2008.

To begin:

Select File -> Load Dictionary to start!
In case of Exception -> Press Continue (it is OK)
Known miss -> selecting a word from the conventional predicted entries list doesn't update the WordNet meanings.
		In that case, type or copy the word in the multi-line textbox and click on the word or words.

Requires Windows XP+ with .NET 1.1+


### INFO and LICENSE ###

(C) Todor Arnaudov - Tosh, 2007, 2020

Initially developed by me for about 3 months+- as a course project at University of Wolverhampton's Research Group in Computational Linguistics in the spring of 2007: https://www.wlv.ac.uk/research/institutes-and-centres/riilp---research-institute-in-information-and-lan/research-group-of-computational-linguistics/

At that form it had a shared (C), according the template course projects/thesis page from the university:


"It is acknowledge that the author of any project work shall own the copyright. However,
by submitting such copyright work for assessment, the author grants to the university a
perpetual royalty-free license to do all or any of those things referred to in Section 16(i)
of the Copyright Designs and Patents Act 1988 (Viz.: to copy work, to issue copies to the
public, to perform or show or play the work in public, to broadcast the work or to make
an adaptation of the work)."

*** VERSIONS ***

That "Smarty"'s executable is freeware, (C) Todor Arnaudov.

It uses:

1) WordNet:

George A. Miller (1995). WordNet: A Lexical Database for English.
Communications of the ACM Vol. 38, No. 11: 39-41.

Christiane Fellbaum (1998, ed.) WordNet: An Electronic Lexical Database. Cambridge, MA: MIT Press.

WordNet: An Electronic Lexical Database(link is external) (citation above) is available from MIT Press(link is external).

https://wordnet.princeton.edu/citing-wordnet


2) OpenNLP - https://opennlp.apache.org/

3) EngBulgUTF.txt - found on the Internet, unknown license, but similar ones are used by other dictionaries like SADict and AEnglish.

4) BalkaNet - the database is not in the redistributables, was only in the Academic version. It is expensive and not free.
"Smarty" reads its format though so if you have it or enter something in that format in the winbul.xml file, aligned to WordNet, it would work.

